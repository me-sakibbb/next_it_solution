document.addEventListener('DOMContentLoaded', () => {
    // Server & Login Elements
    const loginFormContainer = document.getElementById('loginFormContainer');
    const loginEmailInput = document.getElementById('loginEmailInput');
    const loginPasswordInput = document.getElementById('loginPasswordInput');
    const loginBtn = document.getElementById('loginBtn');
    const loginStatus = document.getElementById('loginStatus');
    const loggedInContainer = document.getElementById('loggedInContainer');
    const loggedInShop = document.getElementById('loggedInShop');
    const loggedInBalance = document.getElementById('loggedInBalance');
    const optionsAddBalanceBtn = document.getElementById('optionsAddBalanceBtn');
    const logoutBtn = document.getElementById('logoutBtn');
    const userLimits = document.getElementById('userLimits');
    const mainContent = document.querySelector('main');
    const userAvatar = document.getElementById('userAvatar');

    const profilesList = document.getElementById('profilesList');
    const profileDocInput = document.getElementById('profileDocInput');
    const profileExtractStatus = document.getElementById('profileExtractStatus');
    const profileNameModal = document.getElementById('profileNameModal');
    const newProfileName = document.getElementById('newProfileName');
    const extractedReview = document.getElementById('extractedReview');
    const saveProfileBtn = document.getElementById('saveProfileBtn');
    const cancelSaveProfile = document.getElementById('cancelSaveProfile');
    const aiModelSelector = document.getElementById('aiModelSelector');

    let currentExtractedData = null;

    // Load profiles immediately (no session required)
    loadProfiles();

    // Fast-path: Check storage directly to show UI early
    chrome.storage.local.get(['supabaseSession', 'lastKnownLimits'], (result) => {
        const limits = result.lastKnownLimits || {};
        
        if (result.supabaseSession && result.supabaseSession.user) {
            const sess = result.supabaseSession;
            showLoggedIn(
                sess.user.email, 
                '', 
                limits.shopName || '', 
                limits.balance
            );
            
            if (limits.balance !== undefined) {
                renderLimitsUI(limits);
            }
            
            fetchLimits(sess.access_token);
        }
        
        // Still verify/refresh session via background
        chrome.runtime.sendMessage({ action: 'GET_VALID_SESSION' }, (response) => {
            const session = response && response.session;
            if (session) {
                showLoggedIn(session.user.email);
                fetchLimits(session.access_token);
                // Profiles already loading, but call again to sync if needed
                loadProfiles();
            } else if (!result.supabaseSession) {
                // Only hide if we didn't have a cached session either
                showLoggedOut();
            }
        });
    });

    // Handle AI Model selection persistence
    if (aiModelSelector) {
        chrome.storage.local.get(['selectedAiModel'], (result) => {
            if (result.selectedAiModel) aiModelSelector.value = result.selectedAiModel;
            else {
                aiModelSelector.value = 'fastest';
                chrome.storage.local.set({ selectedAiModel: 'fastest' });
            }
        });
        aiModelSelector.addEventListener('change', () => {
            chrome.storage.local.set({ selectedAiModel: aiModelSelector.value });
        });
    }

    function showLoggedIn(email, name = '', shop = '', balance = undefined) {
        loginFormContainer.classList.add('hidden');
        loggedInContainer.style.display = 'flex';

        if (loggedInShop) loggedInShop.textContent = shop || 'Logged In';
        if (loggedInBalance && balance !== undefined) loggedInBalance.textContent = balance + ' ৳';
        if (optionsAddBalanceBtn) optionsAddBalanceBtn.href = `${CONFIG.SERVER_URL}/dashboard/billing`;

        if (userAvatar) {
            const initial = (shop && shop !== 'Logged In') ? shop.charAt(0) : (email ? email.charAt(0) : '?');
            userAvatar.textContent = initial.toUpperCase();
        }

        mainContent.classList.remove('hidden');
    }

    function showLoggedOut() {
        loginFormContainer.classList.remove('hidden');
        loggedInContainer.style.display = 'none';

        if (loggedInShop) loggedInShop.textContent = '';
        if (loggedInBalance) loggedInBalance.textContent = '0 ৳';

        mainContent.classList.add('hidden');
    }

    async function fetchLimits(token) {
        try {
            const response = await fetch(`${CONFIG.SERVER_URL}/api/extension/check-limit`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await response.json();
            if (response.ok) {
                // Cache for next fast-load
                chrome.storage.local.set({ lastKnownLimits: data });

                // Setup profile headers if they arrived
                if (data.email) {
                    showLoggedIn(data.email, data.userName, data.shopName, data.balance);
                }

                renderLimitsUI(data);
            } else {
                console.error('API Error:', data);
                if (response.status === 401 || response.status === 403 || (data.error && data.error.toLowerCase().includes('token'))) {
                    chrome.storage.local.remove(['supabaseSession'], () => {
                        showLoggedOut();
                    });
                    return;
                }
                userLimits.innerHTML = `
                    <div class="text-xs text-red-500 mt-2 bg-red-50 p-2 rounded-md border border-red-100 font-medium">
                        ${data.error || 'Failed to sync with server. Please log out and re-login.'}
                    </div>
                `;
            }
        } catch (e) {
            console.error('Failed to fetch limits:', e);
            userLimits.innerHTML = `
                <div class="text-xs text-red-500 mt-2 bg-red-50 p-2 rounded-md border border-red-100 font-medium">
                    Connection error. Please check your internet or server URL.
                </div>
            `;
        }
    }

    function renderLimitsUI(data) {
        if (!userLimits) return;
        userLimits.innerHTML = `
            <div style="display: flex; flex-direction: column; gap: 16px;">
                <div>
                    <div style="font-size: 14px; font-weight: 500; color: #1e293b; margin-bottom: 8px;">
                        Current Balance: <span style="color: #2563eb; font-weight: 700; font-size: 18px;">${data.balance ?? 0} ৳</span>
                    </div>
                    <div style="font-size: 13px; color: #64748b; background: #f8fafc; padding: 12px; border-radius: 8px; border: 1px solid #e2e8f0;">
                        <div style="margin-bottom: 8px;"><strong>Pricing Model:</strong></div>
                        <ul style="margin: 0; padding-left: 20px;">
                            <li>Engine Extract & Autofill: <strong>2 ৳</strong></li>
                            <li>Extract to Profile: <strong>1 ৳</strong></li>
                            <li>Fill form using Profile: <strong>1 ৳</strong></li>
                        </ul>
                    </div>
                </div>
            </div>
        `;
    }

    // ==== Profile Management ====

    async function loadProfiles() {
        const { autofillProfiles = [] } = await chrome.storage.local.get(['autofillProfiles']);
        
        if (autofillProfiles.length === 0) {
            profilesList.innerHTML = `<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: var(--text-muted); font-size: 14px;">No profiles saved yet. Upload a document to create one.</div>`;
            return;
        }

        profilesList.innerHTML = autofillProfiles.map((profile, index) => {
            const fieldCount = profile.data ? Object.keys(profile.data).length : 0;
            const createdDate = profile.createdAt ? new Date(profile.createdAt).toLocaleDateString() : 'Unknown';
            
            return `
                <div class="profile-card" data-index="${index}">
                    <div class="profile-delete" data-index="${index}" title="Delete Profile">
                        <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                            <path d="M18 6L6 18M6 6l12 12"/>
                        </svg>
                    </div>
                    <div style="font-weight: 700; font-size: 15px; margin-bottom: 4px; color: var(--text-main);">${profile.name || 'Unnamed Profile'}</div>
                    <div style="font-size: 12px; color: var(--text-muted);">${fieldCount} fields extracted</div>
                    <div style="margin-top: 12px; font-size: 11px; color: #94a3b8;">Created: ${createdDate}</div>
                </div>
            `;
        }).join('');

        // Add delete listeners
        document.querySelectorAll('.profile-delete').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const index = parseInt(e.currentTarget.getAttribute('data-index'));
                deleteProfile(index);
            });
        });
    }

    async function deleteProfile(index) {
        if (!confirm('Are you sure you want to delete this profile?')) return;
        const { autofillProfiles = [] } = await chrome.storage.local.get(['autofillProfiles']);
        autofillProfiles.splice(index, 1);
        await chrome.storage.local.set({ autofillProfiles });
        loadProfiles();
    }

    if (profileDocInput) {
        profileDocInput.addEventListener('change', async (e) => {
            const file = e.target.files[0];
            if (!file) return;

            try {
                profileExtractStatus.textContent = '⏳ Processing document...';
                profileExtractStatus.style.color = 'var(--primary)';
                
                const payload = await prepareFilePayload(file);
                
                chrome.storage.local.get(['selectedAiModel'], (res) => {
                    const aiModel = res.selectedAiModel || 'fastest';
                    
                    chrome.runtime.sendMessage({
                        action: 'EXTRACT_PROFILE',
                        document: payload,
                        aiModel: aiModel
                    }, (response) => {
                        if (response && response.success) {
                            currentExtractedData = response.profileData;
                            showProfileNamingModal(response.profileData);
                            profileExtractStatus.textContent = '✅ Extraction successful!';
                            profileExtractStatus.style.color = 'var(--success)';
                            
                            // Update balance in UI
                            if (response.remainingBalance !== undefined) {
                                if (loggedInBalance) loggedInBalance.textContent = response.remainingBalance + ' ৳';
                            }
                        } else {
                            profileExtractStatus.textContent = '❌ Error: ' + (response?.error || 'Extraction failed');
                            profileExtractStatus.style.color = 'var(--danger)';
                        }
                        profileDocInput.value = '';
                    });
                });
            } catch (err) {
                profileExtractStatus.textContent = '❌ Error: ' + err.message;
                profileExtractStatus.style.color = 'var(--danger)';
                profileDocInput.value = '';
            }
        });
    }

    function showProfileNamingModal(data) {
        extractedReview.innerHTML = Object.entries(data).map(([k, v]) => `
            <div style="margin-bottom: 6px; border-bottom: 1px solid #e2e8f0; padding-bottom: 4px;">
                <span style="font-weight: 600; color: #475569;">${k}:</span> 
                <span style="color: #64748b;">${v || 'N/A'}</span>
            </div>
        `).join('');
        
        newProfileName.value = '';
        profileNameModal.classList.remove('hidden');
    }

    saveProfileBtn.addEventListener('click', async () => {
        const name = newProfileName.value.trim();
        if (!name) {
            alert('Please give your profile a name.');
            return;
        }

        const { autofillProfiles = [] } = await chrome.storage.local.get(['autofillProfiles']);
        autofillProfiles.push({
            id: Date.now().toString(),
            name: name,
            data: currentExtractedData,
            createdAt: new Date().toISOString()
        });

        await chrome.storage.local.set({ autofillProfiles });
        profileNameModal.classList.add('hidden');
        loadProfiles();
        currentExtractedData = null;
    });

    cancelSaveProfile.addEventListener('click', () => {
        profileNameModal.classList.add('hidden');
        currentExtractedData = null;
    });

    // ==== Utility Functions ====

    async function prepareFilePayload(file) {
        const isImage = file.type.startsWith('image/');
        const isPdf = file.type === 'application/pdf';
        const isText = file.type === 'text/plain' || file.name.endsWith('.txt');
        const isDocx = file.name.endsWith('.docx') || file.type.includes('wordprocessingml');

        if (isImage) {
            const base64 = await compressImageToBase64(file, 1.5);
            return { type: 'image', mimeType: file.type || 'image/jpeg', data: base64.split(',')[1] };
        } else if (isPdf) {
            const base64 = await readFileAsBase64(file);
            return { type: 'pdf', mimeType: 'application/pdf', data: base64.split(',')[1] };
        } else if (isText) {
            const text = await readFileAsText(file);
            return { type: 'text', mimeType: 'text/plain', data: text.slice(0, 15000) };
        } else if (isDocx) {
            const text = await extractDocxText(file);
            return { type: 'text', mimeType: 'text/plain', data: text.slice(0, 15000) };
        } else {
            throw new Error('Unsupported file type');
        }
    }

    function readFileAsText(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = e => resolve(e.target.result);
            reader.onerror = reject;
            reader.readAsText(file);
        });
    }

    function readFileAsBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = e => resolve(e.target.result);
            reader.onerror = reject;
            reader.readAsDataURL(file);
        });
    }

    function compressImageToBase64(file, maxSizeMB = 1.5) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = function (event) {
                const img = new Image();
                img.onload = function () {
                    const canvas = document.createElement('canvas');
                    let width = img.width;
                    let height = img.height;
                    const MAX_DIMENSION = 1600;
                    if (width > MAX_DIMENSION || height > MAX_DIMENSION) {
                        if (width > height) {
                            height = Math.round((height * MAX_DIMENSION) / width);
                            width = MAX_DIMENSION;
                        } else {
                            width = Math.round((width * MAX_DIMENSION) / height);
                            height = MAX_DIMENSION;
                        }
                    }
                    canvas.width = width;
                    canvas.height = height;
                    const ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, width, height);
                    const targetBytes = maxSizeMB * 1024 * 1024;
                    let quality = 0.9;
                    let base64 = canvas.toDataURL('image/jpeg', quality);
                    while (base64.length * 0.75 > targetBytes && quality > 0.1) {
                        quality -= 0.1;
                        base64 = canvas.toDataURL('image/jpeg', quality);
                    }
                    resolve(base64);
                };
                img.onerror = reject;
                img.src = event.target.result;
            };
            reader.onerror = reject;
            reader.readAsDataURL(file);
        });
    }

    async function extractDocxText(file) {
        const buffer = await file.arrayBuffer();
        const bytes = new Uint8Array(buffer);
        const decoder = new TextDecoder('utf-8');
        const readUint32 = (offset) => bytes[offset] | (bytes[offset + 1] << 8) | (bytes[offset + 2] << 16) | (bytes[offset + 3] << 24);
        const readUint16 = (offset) => bytes[offset] | (bytes[offset + 1] << 8);
        let offset = 0;
        while (offset < bytes.length - 30) {
            if (bytes[offset] !== 0x50 || bytes[offset + 1] !== 0x4B || bytes[offset + 2] !== 0x03 || bytes[offset + 3] !== 0x04) { offset++; continue; }
            const compression = readUint16(offset + 8);
            const compressedSz = readUint32(offset + 18);
            const filenameLen = readUint16(offset + 26);
            const extraLen = readUint16(offset + 28);
            const filename = decoder.decode(bytes.slice(offset + 30, offset + 30 + filenameLen));
            const dataStart = offset + 30 + filenameLen + extraLen;
            const compressedData = bytes.slice(dataStart, dataStart + compressedSz);
            if (filename === 'word/document.xml') {
                let xmlText;
                if (compression === 0) xmlText = decoder.decode(compressedData);
                else if (compression === 8) {
                    const ds = new DecompressionStream('deflate-raw');
                    const writer = ds.writable.getWriter();
                    const reader = ds.readable.getReader();
                    writer.write(compressedData);
                    writer.close();
                    const chunks = [];
                    while (true) {
                        const { done, value } = await reader.read();
                        if (done) break;
                        chunks.push(value);
                    }
                    const total = chunks.reduce((n, c) => n + c.length, 0);
                    const out = new Uint8Array(total);
                    let pos = 0;
                    for (const chunk of chunks) { out.set(chunk, pos); pos += chunk.length; }
                    xmlText = decoder.decode(out);
                } else throw new Error(`Unsupported DOCX compression method: ${compression}`);
                return xmlText.replace(/<w:p[ />][^>]*>/g, '\n').replace(/<w:br[^>]*\/>/g, '\n').replace(/<w:tab[^>]*\/>/g, '\t').replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&#x[0-9A-Fa-f]+;/g, ' ').replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
            }
            offset = dataStart + compressedSz;
        }
        throw new Error('Not a valid document.xml in docx');
    }

    loginBtn.addEventListener('click', async () => {
        const email = loginEmailInput.value.trim();
        const password = loginPasswordInput.value.trim();

        if (!email || !password) {
            alert('Please enter both email and password.');
            return;
        }

        loginStatus.textContent = 'Logging in...';
        loginStatus.style.color = '#3b82f6';
        loginBtn.disabled = true;

        try {
            const response = await fetch(`${CONFIG.SUPABASE_URL}/auth/v1/token?grant_type=password`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'apikey': CONFIG.SUPABASE_ANON_KEY,
                },
                body: JSON.stringify({ email, password })
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error_description || data.error || 'Login failed');
            }

            chrome.storage.local.set({ supabaseSession: data }, () => {
                loginStatus.textContent = 'Login successful!';
                loginStatus.style.color = '#10b981';
                showLoggedIn(data.user.email);
                fetchLimits(data.access_token);
                setTimeout(() => loginStatus.textContent = '', 3000);
            });
        } catch (error) {
            loginStatus.textContent = error.message;
            loginStatus.style.color = '#ef4444';
        } finally {
            loginBtn.disabled = false;
        }
    });

    logoutBtn.addEventListener('click', () => {
        chrome.storage.local.remove('supabaseSession', () => {
            showLoggedOut();
        });
    });
});
