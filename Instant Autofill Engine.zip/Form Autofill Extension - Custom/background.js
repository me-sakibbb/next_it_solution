// background.js - Next AI Universal Autofill service worker
importScripts('config.js');

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    const handlers = {
        SESSION_GET: () => chrome.storage.session.get([request.key], r => sendResponse({ value: r[request.key] ?? null })),
        SESSION_SET: () => chrome.storage.session.set({ [request.key]: request.value }, () => sendResponse({ success: true })),
        OPEN_OPTIONS: () => { chrome.runtime.openOptionsPage(); sendResponse({ success: true }); },
        GET_VALID_SESSION: () => {
            getValidSession().then(session => sendResponse({ session })).catch(() => sendResponse({ session: null }));
        },
        PERFORM_CUSTOM_AUTOFILL: () => {
            handleCustomAutofill(request, sendResponse);
        },
        EXTRACT_PROFILE: () => {
            handleExtractProfile(request, sendResponse);
        },
        PERFORM_PROFILE_AUTOFILL: () => {
            handleProfileAutofill(request, sendResponse);
        }
    };
    if (handlers[request.action]) { handlers[request.action](); return true; }
});

async function getValidSession() {
    let { supabaseSession } = await chrome.storage.local.get(['supabaseSession']);
    if (!supabaseSession || !supabaseSession.access_token) return null;

    try {
        const payloadBase64 = supabaseSession.access_token.split('.')[1];
        const payload = JSON.parse(atob(payloadBase64.replace(/-/g, '+').replace(/_/g, '/')));
        const expiresAt = payload.exp;

        // Refresh token if it expires in less than 5 minutes
        if (Date.now() / 1000 > expiresAt - 300) {
            const res = await fetch(`${CONFIG.SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'apikey': CONFIG.SUPABASE_ANON_KEY,
                },
                body: JSON.stringify({ refresh_token: supabaseSession.refresh_token })
            });

            if (res.ok) {
                const newData = await res.json();
                supabaseSession = newData;
                await chrome.storage.local.set({ supabaseSession: newData });
            } else {
                await chrome.storage.local.remove('supabaseSession');
                return null;
            }
        }
    } catch (e) {
        console.error('Error handling session token:', e);
        await chrome.storage.local.remove('supabaseSession');
        return null;
    }

    return supabaseSession;
}

async function fetchWithTimeout(resource, options = {}) {
    const { timeout = 45000 } = options;
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), timeout);
    try {
        const response = await fetch(resource, { ...options, signal: controller.signal });
        clearTimeout(id);
        return response;
    } catch (error) {
        clearTimeout(id);
        if (error.name === 'AbortError') throw new Error('Request timed out. Please try again.');
        throw error;
    }
}

async function handleExtractProfile(request, sendResponse) {
    try {
        const supabaseSession = await getValidSession();
        if (!supabaseSession || !supabaseSession.access_token) throw new Error('Login expired.');

        const res = await fetchWithTimeout(`${CONFIG.SERVER_URL}/api/extension/extract-profile`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${supabaseSession.access_token}`
            },
            body: JSON.stringify({ document: request.document, aiModel: request.aiModel }),
        });

        const responseText = await res.text();
        let data;
        try {
            data = JSON.parse(responseText);
        } catch (err) {
            if (responseText.includes('Request Entity Too Large') || res.status === 413) {
                throw new Error('The document is too large. Please use a smaller file or compress the image before extracting.');
            }
            if (res.status === 404) {
                throw new Error(`Server endpoint not found (404). Please check the SERVER_URL in config.js.`);
            }
            if (res.status === 502 || res.status === 503) {
                throw new Error(`Server is temporarily unavailable (Status ${res.status}). Please try again in a moment.`);
            }
            throw new Error(`Server error (Status ${res.status}). ${responseText.slice(0, 100)}`);
        }

        if (!res.ok) throw new Error(data.error || 'Extraction failed');
        sendResponse({ success: true, profileData: data.profileData, remainingBalance: data.remainingBalance });
    } catch (error) {
        sendResponse({ success: false, error: error.message });
    }
}

async function handleProfileAutofill(request, sendResponse) {
    try {
        const supabaseSession = await getValidSession();
        if (!supabaseSession || !supabaseSession.access_token) throw new Error('Login expired.');

        const res = await fetchWithTimeout(`${CONFIG.SERVER_URL}/api/extension/custom-autofill`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${supabaseSession.access_token}`
            },
            body: JSON.stringify({
                profileData: request.profileData,
                targetFields: request.targetFields,
                context: request.context,
                aiModel: request.aiModel
            }),
        });

        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Autofill failed');
        sendResponse({ success: true, data: data.fields, remainingBalance: data.remainingBalance });
    } catch (error) {
        sendResponse({ success: false, error: error.message });
    }
}

async function handleCustomAutofill(request, sendResponse) {
    try {
        const supabaseSession = await getValidSession();

        if (!supabaseSession || !supabaseSession.access_token) {
            throw new Error('Login expired. Please open extension Options to log in again.');
        }

        const API_ENDPOINT = `${CONFIG.SERVER_URL}/api/extension/custom-autofill`;

        const res = await fetchWithTimeout(API_ENDPOINT, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${supabaseSession.access_token}`
            },
            body: JSON.stringify({
                document: request.document,
                targetFields: request.targetFields,
                context: request.context,
                aiModel: request.aiModel
            }),
        });

        const responseText = await res.text();
        let data;
        try {
            data = JSON.parse(responseText);
        } catch (err) {
            if (responseText.includes('Request Entity Too Large') || res.status === 413) {
                throw new Error('The document is too large. Please use a smaller file or compress the image before extracting.');
            }
            throw new Error(`Server returned an invalid response (Status ${res.status}).`);
        }

        if (!res.ok) {
            throw new Error(data.error || 'Server error calling AI Autofill API');
        }

        // data.fields represents the mapped data { "field_id": "value" }
        sendResponse({ success: true, data: data.fields, remainingBalance: data.remainingBalance });
    } catch (error) {
        sendResponse({ success: false, error: error.message });
    }
}

