// content.js - Universal Form autofill content script

// Listen for messages from popup.js
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    if (request.action === 'EXTRACT_PAGE_FIELDS') {
        const fields = scrapeVisibleFields();
        sendResponse({
            success: true,
            fields: fields,
            context: {
                url: window.location.href,
                title: document.title
            }
        });
        return true;
    } else if (request.action === 'FILL_FORM') {
        applyMapping(request.data).then(filledCount => {
            sendResponse({ success: true, filledCount: filledCount });
        });
        return true;
    }
});


// ----------------------------------------------------------------------------
// Overlay UI & On-Page Execution
// ----------------------------------------------------------------------------

function createOverlayUI() {
    // 1. The Floating Button
    const logoUrl = chrome.runtime.getURL('logo.png');
    const floatBtn = document.createElement('button');
    floatBtn.id = 'nx-autofill-float-btn';
    floatBtn.innerHTML = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="display: block;">
            <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
        </svg>
        <span>Instant Autofill</span>
    `;
    Object.assign(floatBtn.style, {
        position: 'fixed',
        bottom: '24px',
        right: '24px',
        zIndex: '999999',
        padding: '12px 20px',
        backgroundColor: '#6366f1',
        color: '#ffffff',
        border: 'none',
        borderRadius: '50px',
        fontFamily: 'system-ui, -apple-system, sans-serif',
        fontSize: '15px',
        fontWeight: '700',
        cursor: 'pointer',
        boxShadow: '0 10px 25px -5px rgba(99, 102, 241, 0.4)',
        display: 'flex',
        alignItems: 'center',
        gap: '8px',
        transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)'
    });

    floatBtn.onmouseover = () => {
        floatBtn.style.transform = 'translateY(-2px) scale(1.02)';
        floatBtn.style.backgroundColor = '#4f46e5';
    };
    floatBtn.onmouseout = () => {
        floatBtn.style.transform = 'translateY(0) scale(1)';
        floatBtn.style.backgroundColor = '#6366f1';
    };

    // 2. Hidden File Input
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = 'image/*,application/pdf,.pdf,.doc,.docx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,.txt,text/plain';
    fileInput.style.display = 'none';

    // 3. Status Toast
    const toast = document.createElement('div');
    toast.id = 'nx-autofill-toast';
    Object.assign(toast.style, {
        position: 'fixed',
        bottom: '80px',
        right: '24px',
        zIndex: '999998',
        padding: '12px 20px',
        backgroundColor: '#1e293b',
        color: '#ffffff',
        borderRadius: '12px',
        fontFamily: 'system-ui, -apple-system, sans-serif',
        fontSize: '14px',
        fontWeight: '500',
        boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
        opacity: '0',
        transform: 'translateY(10px)',
        pointerEvents: 'none',
        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
        display: 'flex',
        alignItems: 'center',
        gap: '10px'
    });

    document.body.appendChild(floatBtn);
    document.body.appendChild(fileInput);
    document.body.appendChild(toast);

    function showToast(message, isLoading = false) {
        toast.style.opacity = '1';
        toast.style.transform = 'translateY(0)';
        const spinner = isLoading ? `<div style="width:16px;height:16px;border:2px solid #cbd5e1;border-top-color:#3b82f6;border-radius:50%;animation:nx-spin 1s linear infinite;"></div>` : '';
        toast.innerHTML = `${spinner} <span>${message}</span>`;
    }

    function hideToast(delay = 3000) {
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateY(10px)';
        }, delay);
    }

    // Add keyframes if not exists
    if (!document.getElementById('nx-spinner-styles')) {
        const style = document.createElement('style');
        style.id = 'nx-spinner-styles';
        style.textContent = `@keyframes nx-spin { to { transform: rotate(360deg); } }`;
        document.head.appendChild(style);
    }

    // 4. Menu Overlay
    let menuOpen = false;
    const menuContainer = document.createElement('div');
    menuContainer.id = 'nx-autofill-menu';
    Object.assign(menuContainer.style, {
        position: 'fixed',
        bottom: '80px',
        right: '24px',
        zIndex: '999999',
        backgroundColor: '#ffffff',
        border: '1px solid #e2e8f0',
        borderRadius: '16px',
        boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1)',
        padding: '12px',
        display: 'none',
        flexDirection: 'column',
        gap: '8px',
        width: '280px',
        fontFamily: 'system-ui, -apple-system, sans-serif',
        maxHeight: '400px',
        overflowY: 'auto'
    });
    document.body.appendChild(menuContainer);

    // AI Model selected in overlay
    let selectedOverlayModel = 'fastest';
    chrome.storage.local.get(['selectedAiModel'], (res) => {
        if (res.selectedAiModel) selectedOverlayModel = res.selectedAiModel;
    });

    // Add CSS for hover states
    if (!document.getElementById('nx-menu-styles')) {
        const hStyle = document.createElement('style');
        hStyle.id = 'nx-menu-styles';
        hStyle.textContent = `
            #nx-btn-instant:hover { background: #e0e7ff !important; border-color: #818cf8 !important; }
            .nx-profile-btn:hover { background: #f1f5f9 !important; border-color: #cbd5e1 !important; transform: translateY(-1px); }
        `;
        document.head.appendChild(hStyle);
    }

    // Hide menu if clicked outside
    document.addEventListener('click', (e) => {
        if (menuOpen && !menuContainer.contains(e.target) && !floatBtn.contains(e.target)) {
            menuContainer.style.display = 'none';
            menuOpen = false;
        }
    });

    // Formatting menu
    function renderMenu() {
        menuContainer.innerHTML = `<div style="text-align:center; padding: 10px; color: #64748b; font-size: 13px;">Loading...</div>`;
        chrome.storage.local.get(['autofillProfiles', 'selectedAiModel'], (result) => {
            if (result.selectedAiModel) selectedOverlayModel = result.selectedAiModel;
            const profiles = result.autofillProfiles || [];

            let html = `
                <div style="font-size: 14px; font-weight: 700; color: #0f172a; margin-bottom: 8px; padding-bottom: 8px; border-bottom: 1px solid #e2e8f0; display: flex; align-items: center; gap: 8px;">
                    <img src="${logoUrl}" style="width: 18px; height: 18px; border-radius: 4px; object-fit: contain;">
                    Instant Autofill Engine
                </div>
                
                
                <div style="margin-bottom: 12px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: 10px; display: flex; align-items: center; justify-content: space-between;">
                    <span style="font-size: 11px; font-weight: 700; color: #64748b;">AI ENGINE</span>
                    <select id="nx-menu-model-select" style="padding: 4px 8px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 11px; font-weight: 600; background: white; outline: none; cursor: pointer;">
                        <option value="fastest" ${selectedOverlayModel === 'fastest' ? 'selected' : ''}>⚡ AI 1 (Fastest)</option>
                        <option value="fast" ${selectedOverlayModel === 'fast' ? 'selected' : ''}>🏃 AI 2 (Fast)</option>
                        <option value="quality" ${selectedOverlayModel === 'quality' ? 'selected' : ''}>🧠 AI 3 (Quality)</option>
                    </select>
                </div>

                <button id="nx-btn-instant" style="display: flex; align-items: center; gap: 10px; background: #f5f3ff; color: #6366f1; border: 1px dashed #c7d2fe; padding: 10px 12px; border-radius: 10px; font-weight: 600; cursor: pointer; text-align: left; font-size: 13px; transition: all 0.2s; width: 100%;">
                    <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M17 8l-5-5-5 5M12 3v12"/></svg>
                    <div>
                        <div style="font-size: 13px; line-height: 1;">Upload Document</div>
                        <div style="font-size: 11px; color: #6366f1; font-weight: 500; margin-top: 4px;">Cost: 2 ৳ • Instant Fill</div>
                    </div>
                </button>
            `;

            if (profiles.length > 0) {
                html += `<div style="font-size: 12px; font-weight: 700; color: #64748b; margin-top: 16px; margin-bottom: 8px; padding-left: 4px;">SAVED PROFILES</div>`;
                profiles.forEach((p, i) => {
                    html += `
                        <button class="nx-profile-btn" data-index="${i}" style="display: flex; align-items: center; gap: 10px; background: #f8fafc; color: #334155; border: 1px solid #e2e8f0; padding: 10px 12px; border-radius: 10px; font-weight: 600; cursor: pointer; text-align: left; transition: all 0.2s; width: 100%;">
                            <svg width="16" height="16" fill="none" stroke="#64748b" stroke-width="2.5" viewBox="0 0 24 24">
                                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                <circle cx="12" cy="7" r="4"></circle>
                            </svg>
                            <div>
                                <div style="color: #0f172a; font-size: 13px; line-height: 1;">${p.name}</div>
                                <div style="font-size: 11px; color: #64748b; font-weight: 500; margin-top: 4px;">Cost: 1 ৳ • ${Object.keys(p.data).length} fields</div>
                            </div>
                        </button>
                    `;
                });
            } else {
                html += `<div style="font-size: 12px; color: #94a3b8; margin-top: 12px; text-align: center; padding: 10px; background: #f8fafc; border-radius: 8px;">No profiles saved yet.</div>`;
            }

            menuContainer.innerHTML = html;

            const modelSelector = document.getElementById('nx-menu-model-select');
            if (modelSelector) {
                modelSelector.onchange = (e) => {
                    selectedOverlayModel = e.target.value;
                    chrome.storage.local.set({ selectedAiModel: e.target.value });
                };
            }

            document.getElementById('nx-btn-instant').onclick = () => {
                menuContainer.style.display = 'none';
                menuOpen = false;
                fileInput.click();
            };

            document.querySelectorAll('.nx-profile-btn').forEach(btn => {
                btn.onclick = () => {
                    const index = parseInt(btn.getAttribute('data-index'));
                    const profile = profiles[index];
                    menuContainer.style.display = 'none';
                    menuOpen = false;
                    performProfileAutofill(profile);
                };
            });
        });
    }

    // Wiring up logic
    floatBtn.onclick = async () => {
        // Quick session check before opening UI
        chrome.runtime.sendMessage({ action: 'GET_VALID_SESSION' }, (response) => {
            if (!response || !response.session) {
                alert('NX Autofill: Please login from the extension popup first.');
                return;
            }
            if (menuOpen) {
                menuContainer.style.display = 'none';
                menuOpen = false;
            } else {
                renderMenu();
                menuContainer.style.display = 'flex';
                menuOpen = true;
            }
        });
    };

    async function performProfileAutofill(profile) {
        floatBtn.style.pointerEvents = 'none';
        floatBtn.style.opacity = '0.7';

        try {
            showToast('Scanning forms...', true);
            const targetFields = scrapeVisibleFields();

            if (!targetFields || targetFields.length === 0) {
                showToast('No fillable fields found on this page.');
                hideToast();
                floatBtn.style.pointerEvents = 'auto';
                floatBtn.style.opacity = '1';
                return;
            }

            showToast('AI is filling forms (cost 1 ৳)...', true);

            chrome.runtime.sendMessage({
                action: "PERFORM_PROFILE_AUTOFILL",
                profileData: profile.data,
                targetFields: targetFields,
                context: { url: window.location.href, title: document.title },
                aiModel: selectedOverlayModel
            }, async (backgroundResponse) => {
                if (!backgroundResponse) {
                    showToast('Error: Extension background script did not respond. Please reload the page.');
                } else if (!backgroundResponse.success) {
                    showToast('Error: ' + (backgroundResponse.error || 'AI Mapping failed.'));
                } else {
                    showToast('Applying data...', true);
                    const count = await applyMapping(backgroundResponse.data);
                    if (count > 0) showCompletionModal(count);
                    showToast(`✅ Filled ${count} fields!`);
                }
                hideToast(5000);

                floatBtn.style.pointerEvents = 'auto';
                floatBtn.style.opacity = '1';
            });
        } catch (err) {
            console.error('NX Autofill Error:', err);
            showToast('Error: ' + err.message);
            hideToast(4000);
            floatBtn.style.pointerEvents = 'auto';
            floatBtn.style.opacity = '1';
        }
    }

    fileInput.onchange = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        try {
            floatBtn.style.pointerEvents = 'none';
            floatBtn.style.opacity = '0.7';

            showToast('Loading document...', true);

            // 1. Convert file
            let payload = null;
            const isImage = file.type.startsWith('image/');
            const isPdf = file.type === 'application/pdf';
            const isText = file.type === 'text/plain' || file.name.endsWith('.txt');
            const isDocx = file.name.endsWith('.docx') || file.type.includes('wordprocessingml');

            if (isImage) {
                const base64 = await compressImageToBase64(file, 1.5);
                payload = { type: 'image', mimeType: file.type || 'image/jpeg', data: base64.split(',')[1] };
            } else if (isPdf) {
                const base64 = await readFileAsBase64(file);
                payload = { type: 'pdf', mimeType: 'application/pdf', data: base64.split(',')[1] };
            } else if (isText) {
                const text = await readFileAsText(file);
                payload = { type: 'text', mimeType: 'text/plain', data: text.slice(0, 15000) };
            } else if (isDocx) {
                const text = await extractDocxText(file);
                payload = { type: 'text', mimeType: 'text/plain', data: text.slice(0, 15000) };
            } else {
                throw new Error('Unsupported file type');
            }

            // 2. Scrape fields
            showToast('Scanning forms...', true);
            const targetFields = scrapeVisibleFields();

            if (!targetFields || targetFields.length === 0) {
                showToast('No fillable fields found on this page.');
                hideToast();
                return;
            }

            // 3. Send AI Request via Background script
            showToast('AI is filling forms (cost 2 ৳)...', true);

            chrome.runtime.sendMessage({
                action: "PERFORM_CUSTOM_AUTOFILL",
                document: payload,
                targetFields: targetFields,
                context: { url: window.location.href, title: document.title },
                aiModel: selectedOverlayModel
            }, async (backgroundResponse) => {
                if (!backgroundResponse) {
                    showToast('Error: Extension background script did not respond.');
                } else if (!backgroundResponse.success) {
                    showToast('Error: ' + (backgroundResponse.error || 'AI Extraction failed.'));
                } else {
                    showToast('Applying data...', true);
                    const count = await applyMapping(backgroundResponse.data);
                    if (count > 0) showCompletionModal(count);
                    showToast(`✅ Filled ${count} fields!`);
                }

                hideToast(5000);

                // Reset
                fileInput.value = '';
                floatBtn.style.pointerEvents = 'auto';
                floatBtn.style.opacity = '1';
            });

        } catch (err) {
            console.error('NX Autofill Error:', err);
            showToast('Error: ' + err.message);
            hideToast(4000);

            fileInput.value = '';
            floatBtn.style.pointerEvents = 'auto';
            floatBtn.style.opacity = '1';
        }
    };
}

// Initialize floating UI immediately
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', createOverlayUI);
} else {
    createOverlayUI();
}


// ----------------------------------------------------------------------------
// File Conversion Utilities
// ----------------------------------------------------------------------------

function readFileAsText(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = e => resolve(e.target.result);
        reader.onerror = reject;
        reader.readAsText(file);
    });
}

function readFileAsBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = e => resolve(e.target.result);
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

function compressImageToBase64(file, maxSizeMB = 1.5) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = function (event) {
            const img = new Image();
            img.onload = function () {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;
                const MAX_DIMENSION = 1600;
                if (width > MAX_DIMENSION || height > MAX_DIMENSION) {
                    if (width > height) {
                        height = Math.round((height * MAX_DIMENSION) / width);
                        width = MAX_DIMENSION;
                    } else {
                        width = Math.round((width * MAX_DIMENSION) / height);
                        height = MAX_DIMENSION;
                    }
                }
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, width, height);

                const targetBytes = maxSizeMB * 1024 * 1024;
                let quality = 0.9;
                let base64 = canvas.toDataURL('image/jpeg', quality);
                while (base64.length * 0.75 > targetBytes && quality > 0.1) {
                    quality -= 0.1;
                    base64 = canvas.toDataURL('image/jpeg', quality);
                }
                resolve(base64);
            };
            img.onerror = reject;
            img.src = event.target.result;
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

async function extractDocxText(file) {
    const buffer = await file.arrayBuffer();
    const bytes = new Uint8Array(buffer);
    const decoder = new TextDecoder('utf-8');
    const readUint32 = (offset) => bytes[offset] | (bytes[offset + 1] << 8) | (bytes[offset + 2] << 16) | (bytes[offset + 3] << 24);
    const readUint16 = (offset) => bytes[offset] | (bytes[offset + 1] << 8);

    let offset = 0;
    while (offset < bytes.length - 30) {
        if (bytes[offset] !== 0x50 || bytes[offset + 1] !== 0x4B || bytes[offset + 2] !== 0x03 || bytes[offset + 3] !== 0x04) {
            offset++;
            continue;
        }

        const compression = readUint16(offset + 8);
        const compressedSz = readUint32(offset + 18);
        const filenameLen = readUint16(offset + 26);
        const extraLen = readUint16(offset + 28);
        const filename = decoder.decode(bytes.slice(offset + 30, offset + 30 + filenameLen));
        const dataStart = offset + 30 + filenameLen + extraLen;
        const compressedData = bytes.slice(dataStart, dataStart + compressedSz);

        if (filename === 'word/document.xml') {
            let xmlText;
            if (compression === 0) {
                xmlText = decoder.decode(compressedData);
            } else if (compression === 8) {
                const ds = new DecompressionStream('deflate-raw');
                const writer = ds.writable.getWriter();
                const reader = ds.readable.getReader();
                writer.write(compressedData);
                writer.close();

                const chunks = [];
                while (true) {
                    const { done, value } = await reader.read();
                    if (done) break;
                    chunks.push(value);
                }

                const total = chunks.reduce((n, c) => n + c.length, 0);
                const out = new Uint8Array(total);
                let pos = 0;
                for (const chunk of chunks) { out.set(chunk, pos); pos += chunk.length; }
                xmlText = decoder.decode(out);
            } else {
                throw new Error(`Unsupported DOCX compression method: ${compression}`);
            }

            return xmlText
                .replace(/<w:p[ />][^>]*>/g, '\n')
                .replace(/<w:br[^>]*\/>/g, '\n')
                .replace(/<w:tab[^>]*\/>/g, '\t')
                .replace(/<[^>]+>/g, '')
                .replace(/&amp;/g, '&')
                .replace(/&lt;/g, '<')
                .replace(/&gt;/g, '>')
                .replace(/&quot;/g, '"')
                .replace(/&apos;/g, "'")
                .replace(/&#x[0-9A-Fa-f]+;/g, ' ')
                .replace(/[ \t]+/g, ' ')
                .replace(/\n{3,}/g, '\n\n')
                .trim();
        }
        offset = dataStart + compressedSz;
    }
    throw new Error('Could not find document text in DOCX.');
}


// ----------------------------------------------------------------------------
// Field Scraping Logic
// ----------------------------------------------------------------------------

function isDateField(el) {
    if (!el) return false;
    if (el.type === 'date') return true;
    const name = (el.name || el.id || '').toLowerCase();
    const placeholder = (el.placeholder || '').toLowerCase();
    const label = (document.querySelector(`label[for="${el.id}"]`)?.innerText || '').toLowerCase();
    
    return name.includes('date') || name.includes('dob') || name.includes('birth')
        || placeholder.includes('dd/mm') || placeholder.includes('mm/dd') || placeholder.includes('yyyy')
        || label.includes('date') || label.includes('birth')
        || el.classList.contains('datepicker') || el.classList.contains('hasDatepicker');
}

function scrapeVisibleFields() {
    const inputs = document.querySelectorAll('input, select, textarea');
    const fields = [];

    inputs.forEach(function (input) {
        if (!isVisible(input)) return;

        const type = input.type ? input.type.toLowerCase() : '';
        if (type === 'hidden' || type === 'submit' || type === 'button' || type === 'file' || type === 'reset') return;

        let label = '';
        if (input.id) {
            const labelEl = document.querySelector(`label[for="${input.id}"]`);
            if (labelEl) label = labelEl.innerText.trim();
        }
        if (!label && input.parentElement) {
            const parentLabel = input.parentElement.querySelector('label');
            if (parentLabel) label = parentLabel.innerText.trim();
        }
        if (!label) label = input.placeholder || input.name || '';

        const fieldInfo = {
            id: input.id || input.name,
            type: input.type,
            tagName: input.tagName.toLowerCase(),
            label: label,
            placeholder: input.placeholder || '',
            name: input.name || '',
        };

        if (isDateField(input)) {
            // Explicitly tell the AI about the desired format
            let format = 'dd/mm/yyyy'; // default
            if (input.placeholder && (input.placeholder.toLowerCase().includes('dd') || input.placeholder.toLowerCase().includes('mm') || input.placeholder.toLowerCase().includes('yy'))) {
                format = input.placeholder;
            }
            fieldInfo.label += ` (Return Date in this format: ${format})`;
            fieldInfo.context = `Date field. Required format: ${format}`;
        }

        if (input.tagName.toLowerCase() === 'select') {
            fieldInfo.options = extractSelectOptions(input);
        }

        // Only include fields that have some form of identifier
        if (fieldInfo.id || fieldInfo.name || fieldInfo.label) {
            fields.push(fieldInfo);
        }
    });

    return fields;
}

function isVisible(elem) {
    return !!(elem && (elem.offsetWidth || elem.offsetHeight || elem.getClientRects().length));
}

function extractSelectOptions(selectEl) {
    const options = [];
    for (let i = 0; i < selectEl.options.length; i++) {
        options.push({
            value: selectEl.options[i].value,
            text: selectEl.options[i].text.trim()
        });
    }
    // Limit to prevent huge payloads, but capture enough for AI to guess
    return options.slice(0, 30);
}


// ----------------------------------------------------------------------------
// Apply Mapping Logic
// ----------------------------------------------------------------------------

async function applyMapping(mapping) {
    let filledCount = 0;
    const filledElements = [];

    for (let key in mapping) {
        const value = mapping[key];
        if (!value || value === "null" || value === "") continue;

        let el = document.getElementById(key) || document.querySelector(`[name="${key}"]`);

        // If not found by exact key, try a fallback search by name if they key has spaces or is derived
        if (!el) {
            const elsName = Array.from(document.querySelectorAll('input, select, textarea')).find(e => e.name === key || e.id === key);
            if (elsName) el = elsName;
        }

        if (!el || filledElements.includes(el)) continue;

        let filled = false;

        if (el.type === 'radio') {
            const radios = document.querySelectorAll(`[name="${el.name}"]`);
            for (let i = 0; i < radios.length; i++) {
                const rVal = String(radios[i].value).toLowerCase().trim();
                const targetVal = String(value).toLowerCase().trim();
                const rLabel = (document.querySelector(`label[for="${radios[i].id}"]`)?.innerText || '').toLowerCase().trim();

                if (rVal === targetVal || rLabel.includes(targetVal) || targetVal.includes(rLabel)) {
                    if (!radios[i].checked) {
                        radios[i].click();
                        radios[i].checked = true;
                        radios[i].dispatchEvent(new Event('change', { bubbles: true }));
                    }
                    filled = true;
                    el = radios[i];
                    break;
                }
            }
        } else if (el.type === 'checkbox') {
            const isChecked = ['yes', 'true', '1', 'on'].includes(String(value).toLowerCase().trim());
            if (el.checked !== isChecked) {
                el.click();
                el.checked = isChecked;
                el.dispatchEvent(new Event('change', { bubbles: true }));
            }
            filled = true;
        } else if (el.tagName.toLowerCase() === 'select') {
            filled = setSelectValue(el, value);
        } else {
            // Text inputs, textareas, etc.
            let finalValue = value;

            // Basic date field handling if HTML5
            if (el.type === 'date') {
                let d = String(value).trim();
                // Check if it's already YYYY-MM-DD
                if (/^\d{4}-\d{2}-\d{2}$/.test(d)) {
                    finalValue = d;
                } else {
                    // Try to parse DD/MM/YYYY or DD-MM-YYYY
                    const m = d.match(/^(\d{1,2})[\/-](\d{1,2})[\/-](\d{4})$/);
                    if (m) {
                        finalValue = `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
                    } else {
                        // Fallback to native Date parser
                        const parsedDate = new Date(value);
                        if (!isNaN(parsedDate.getTime())) {
                            finalValue = parsedDate.toISOString().split('T')[0];
                        }
                    }
                }
            }

            setNativeValue(el, finalValue);
            filled = true;
        }

        if (filled) {
            filledCount++;
            filledElements.push(el);

            // Visual feedback
            el.style.backgroundColor = '#e6fffa';
            el.style.transition = 'background-color 0.5s';
            (function (elem) { setTimeout(function () { elem.style.backgroundColor = ''; }, 2000); })(el);
        }
    }
    return filledCount;
}

// Emulate native input change to trigger frameworks (React, Angular, Vue, etc.)
function setNativeValue(element, value) {
    const last = element.value;
    element.value = value;
    const tracker = element._valueTracker;
    if (tracker) tracker.setValue(last);

    // Dispatch events
    element.dispatchEvent(new Event('focus', { bubbles: true }));
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
    element.dispatchEvent(new Event('blur', { bubbles: true }));
}

function setSelectValue(el, value) {
    if (value == null) return false;
    const valStr = String(value).toLowerCase().trim();

    // 1. Exact value match
    for (let i = 0; i < el.options.length; i++) {
        if (el.options[i].value === String(value)) {
            setNativeValue(el, el.options[i].value);
            return true;
        }
    }

    // 2. Exact text match
    for (let i = 0; i < el.options.length; i++) {
        if (el.options[i].text.toLowerCase().trim() === valStr) {
            setNativeValue(el, el.options[i].value);
            return true;
        }
    }

    // 3. Best partial match (find option with highest similarity or inclusion)
    let bestMatchIndex = -1;
    let bestMatchScore = 0;
    const valueWords = valStr.split(/\s+/);

    for (let i = 0; i < el.options.length; i++) {
        const optText = el.options[i].text.toLowerCase().trim();
        if (!optText || el.options[i].value === "" || el.options[i].value === "-1") continue;

        if (optText.includes(valStr) || valStr.includes(optText)) {
            setNativeValue(el, el.options[i].value);
            return true;
        }

        let matchCount = 0;
        valueWords.forEach(word => {
            if (word.length > 2 && optText.includes(word)) matchCount++;
        });

        if (matchCount > bestMatchScore) {
            bestMatchScore = matchCount;
            bestMatchIndex = i;
        }
    }

    if (bestMatchIndex !== -1) {
        setNativeValue(el, el.options[bestMatchIndex].value);
        return true;
    }

    return false;
}

// ----------------------------------------------------------------------------
// Utility
// ----------------------------------------------------------------------------
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function showCompletionModal(count) {
    const existing = document.getElementById('nx-completion-modal');
    if (existing) existing.remove();

    const backdrop = document.createElement('div');
    backdrop.id = 'nx-completion-modal';
    Object.assign(backdrop.style, {
        position: 'fixed', inset: '0', width: '100%', height: '100%',
        background: 'rgba(15, 23, 42, 0.4)', backdropFilter: 'blur(4px)',
        zIndex: '2147483647', display: 'flex', justifyContent: 'center', alignItems: 'center',
        fontFamily: 'system-ui, -apple-system, sans-serif',
        animation: 'nx-fade-in 0.3s ease-out forwards', opacity: '0'
    });

    const card = document.createElement('div');
    Object.assign(card.style, {
        background: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '24px',
        padding: '32px', width: '400px', maxWidth: 'calc(100vw - 48px)',
        boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)',
        display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', gap: '20px',
        animation: 'nx-slide-up 0.4s cubic-bezier(0.34, 1.56, 0.64, 1) forwards'
    });

    card.innerHTML = `
        <div style="width: 64px; height: 64px; border-radius: 20px; background: rgba(34, 197, 94, 0.1); display: flex; align-items: center; justify-content: center; margin-bottom: 8px;">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#16a34a" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
        </div>
        <div>
            <h2 style="margin: 0; color: #0f172a; font-size: 22px; font-weight: 800; line-height: 1.2;">অটোফিল সফল হয়েছে!</h2>
            <p style="margin: 12px 0 0 0; color: #475569; font-size: 15px; line-height: 1.6; font-weight: 500;">
                ${count ? count + ' টি তথ্য পূরণ করা হয়েছে। ' : ''}এআই (AI) দিয়ে ফর্মটি অটোফিল করা হয়েছে। সাবমিট করার আগে অনুগ্রহ করে সব তথ্যগুলো একবার যাচাই করে নিন।
            </p>
        </div>
        <button id="nx-modal-close" style="width: 100%; padding: 14px; background: #6366f1; color: white; border: none; border-radius: 14px; font-weight: 700; font-size: 15px; cursor: pointer; transition: all 0.2s; box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);">ঠিক আছে, যাচাই করে নিচ্ছি</button>
    `;

    if (!document.getElementById('nx-modal-keyframes')) {
        const style = document.createElement('style');
        style.id = 'nx-modal-keyframes';
        style.textContent = `
            @keyframes nx-fade-in { from { opacity: 0; } to { opacity: 1; } }
            @keyframes nx-slide-up { from { opacity: 0; transform: translateY(24px) scale(0.96); } to { opacity: 1; transform: translateY(0) scale(1); } }
        `;
        document.head.appendChild(style);
    }

    document.body.appendChild(backdrop);
    backdrop.appendChild(card);

    document.getElementById('nx-modal-close').onclick = () => {
        backdrop.style.opacity = '0';
        backdrop.style.transform = 'translateY(10px) scale(0.98)';
        backdrop.style.transition = 'all 0.2s ease';
        setTimeout(() => backdrop.remove(), 200);
    };

    backdrop.onclick = (e) => {
        if (e.target === backdrop) backdrop.remove();
    };

    requestAnimationFrame(() => {
        backdrop.style.opacity = '1';
    });
}