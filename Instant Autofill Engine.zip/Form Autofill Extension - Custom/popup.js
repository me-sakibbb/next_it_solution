const tabInstant = document.getElementById('tab-instant');
const tabProfile = document.getElementById('tab-profile');
const viewInstant = document.getElementById('view-instant');
const viewProfile = document.getElementById('view-profile');
const profileSelect = document.getElementById('profile-select');
const profileFieldsContainer = document.getElementById('profile-fields-container');
const addFieldContainer = document.getElementById('add-field-container');
const addFieldBtn = document.getElementById('add-field-btn');
const profileAutofillBtn = document.getElementById('profile-autofill-btn');
const manageProfilesLink = document.getElementById('manage-profiles-link');

const autofillBtn = document.getElementById('autofill-btn');
const optionsBtn = document.getElementById('options-btn');
const sidebarBtn = document.getElementById('sidebar-btn');
const loginRequired = document.getElementById('login-required');
const popupContent = document.getElementById('popup-content');
const loginSettingsBtn = document.getElementById('login-settings-btn');
const popupShop = document.getElementById('popup-shop');
const popupPlan = document.getElementById('popup-plan');
const popupBalance = document.getElementById('popup-balance');
const addBalanceBtn = document.getElementById('add-balance-btn');
const extractionStatus = document.getElementById('extractionStatus');
const aiModelSelector = document.getElementById('aiModelSelector');

const docInput = document.getElementById('docInput');
const docDropZone = document.getElementById('docDropZone');
const docFileInfo = document.getElementById('docFileInfo');
const docFileName = document.getElementById('docFileName');
const docFileSize = document.getElementById('docFileSize');
const docClearBtn = document.getElementById('docClearBtn');

let currentSession = null;
let currentFileData = null;
let hasBalance = false;
let currentBalance = 0;
let selectedProfileIndex = -1;

document.addEventListener('DOMContentLoaded', () => {
    // Load profiles immediately
    loadProfiles();

    // Fast-path: Check storage directly to show UI early
    chrome.storage.local.get(['supabaseSession', 'lastKnownLimits'], (result) => {
        const limits = result.lastKnownLimits || {};
        
        if (result.supabaseSession && result.supabaseSession.user) {
            currentSession = result.supabaseSession;
            loginRequired.classList.add('hidden');
            popupContent.classList.remove('hidden');
            
            // Populating UI with cached data
            if (limits.shopName) popupShop.textContent = limits.shopName;
            if (limits.balance !== undefined) {
                currentBalance = limits.balance;
                popupBalance.textContent = `${limits.balance} ৳`;
                hasBalance = limits.balance >= 1;
            }
            if (limits.plan) {
                popupPlan.textContent = limits.plan.replace('_', ' ');
            }
            
            fetchLimits(currentSession.access_token);
        }

        // Still verify/refresh session via background
        chrome.runtime.sendMessage({ action: 'GET_VALID_SESSION' }, (response) => {
            const session = response && response.session;
            if (session && session.access_token) {
                currentSession = session;
                loginRequired.classList.add('hidden');
                popupContent.classList.remove('hidden');
                fetchLimits(session.access_token);
                // Profiles already loading, but call again to ensure sync
                loadProfiles();
            } else if (!result.supabaseSession) {
                loginRequired.classList.remove('hidden');
                popupContent.classList.add('hidden');
            }
        });
    });

    // Handle AI Model selection persistence
    if (aiModelSelector) {
        chrome.storage.local.get(['selectedAiModel'], (result) => {
            if (result.selectedAiModel) aiModelSelector.value = result.selectedAiModel;
            else {
                aiModelSelector.value = 'fastest';
                chrome.storage.local.set({ selectedAiModel: 'fastest' });
            }
        });
        aiModelSelector.addEventListener('change', () => {
            chrome.storage.local.set({ selectedAiModel: aiModelSelector.value });
        });
    }

    // Tab Switching
    tabInstant.addEventListener('click', () => {
        tabInstant.classList.add('active');
        tabProfile.classList.remove('active');
        viewInstant.classList.remove('hidden');
        viewProfile.classList.add('hidden');
        extractionStatus.textContent = '';
    });

    tabProfile.addEventListener('click', () => {
        tabProfile.classList.add('active');
        tabInstant.classList.remove('active');
        viewProfile.classList.remove('hidden');
        viewInstant.classList.add('hidden');
        extractionStatus.textContent = '';
        loadProfiles();
    });

    profileSelect.addEventListener('change', (e) => {
        selectedProfileIndex = parseInt(e.target.value);
        if (selectedProfileIndex !== -1) {
            renderProfileFields();
            profileFieldsContainer.classList.remove('hidden');
            addFieldContainer.classList.remove('hidden');
        } else {
            profileFieldsContainer.classList.add('hidden');
            addFieldContainer.classList.add('hidden');
        }
        updateButtonsState();
    });

    addFieldBtn.addEventListener('click', () => {
        addNewField();
    });

    if (manageProfilesLink) {
        manageProfilesLink.addEventListener('click', (e) => {
            e.preventDefault();
            chrome.runtime.openOptionsPage();
        });
    }
});

async function fetchLimits(token) {
    try {
        const response = await fetch(`${CONFIG.SERVER_URL}/api/extension/check-limit`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        const data = await response.json();
        if (response.ok) {
            // Cache for next fast-load
            chrome.storage.local.set({ lastKnownLimits: data });

            if (data.shopName) popupShop.textContent = data.shopName;
            if (data.balance !== undefined) {
                currentBalance = data.balance;
                popupBalance.textContent = `${data.balance} ৳`;
                hasBalance = data.balance >= 1;
            }
            
            if (addBalanceBtn) {
                addBalanceBtn.href = `${CONFIG.SERVER_URL}/dashboard/billing`;
            }

            const planName = data.plan ? data.plan.replace('_', ' ') : 'Free';
            popupPlan.textContent = planName;

            updateButtonsState();
        } else {
            setStatus('Authentication Error', '#ef4444');
            hasBalance = false;
            updateButtonsState();
        }
    } catch (e) {
        console.error('Failed to fetch limits:', e);
        setStatus('Connection Error', '#ef4444');
        hasBalance = false;
        updateButtonsState();
    }
}

// ==== Profile Handling ====

async function loadProfiles() {
    const { autofillProfiles = [] } = await chrome.storage.local.get(['autofillProfiles']);
    
    // Save current selection if possible
    const prevValue = profileSelect.value;

    if (autofillProfiles.length === 0) {
        profileSelect.innerHTML = '<option value="-1">No profiles found</option>';
        profileFieldsContainer.innerHTML = '';
        profileFieldsContainer.classList.add('hidden');
        addFieldContainer.classList.add('hidden');
        selectedProfileIndex = -1;
        updateButtonsState();
        return;
    }

    profileSelect.innerHTML = '<option value="-1">Select a profile...</option>' + 
        autofillProfiles.map((p, i) => `
            <option value="${i}" ${selectedProfileIndex === i ? 'selected' : ''}>${p.name}</option>
        `).join('');

    if (selectedProfileIndex !== -1) {
        renderProfileFields();
        profileFieldsContainer.classList.remove('hidden');
        addFieldContainer.classList.remove('hidden');
    } else {
        profileFieldsContainer.classList.add('hidden');
        addFieldContainer.classList.add('hidden');
    }
}

async function renderProfileFields() {
    if (selectedProfileIndex === -1) return;
    
    const { autofillProfiles = [] } = await chrome.storage.local.get(['autofillProfiles']);
    const profile = autofillProfiles[selectedProfileIndex];
    if (!profile) return;

    const data = profile.data || {};
    const keys = Object.keys(data);

    if (keys.length === 0) {
        profileFieldsContainer.innerHTML = `
            <div style="text-align: center; padding: 12px; color: var(--text-muted); font-size: 12px;">
                No fields in this profile. Add one below.
            </div>`;
    } else {
        profileFieldsContainer.innerHTML = keys.map((key, i) => `
            <div class="profile-field-row" data-key="${key}">
                <div class="field-key">
                    <input type="text" class="editable-input key-input" value="${key}" placeholder="Label">
                </div>
                <div class="field-val">
                    <input type="text" class="editable-input val-input" value="${data[key]}" placeholder="Value">
                </div>
                <div class="remove-field" title="Remove Field">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="18" y1="6" x2="6" y2="18"></line>
                        <line x1="6" y1="6" x2="18" y2="18"></line>
                    </svg>
                </div>
            </div>
        `).join('');
    }

    // Attach listeners for editing
    profileFieldsContainer.querySelectorAll('.profile-field-row').forEach(row => {
        const keyInput = row.querySelector('.key-input');
        const valInput = row.querySelector('.val-input');
        const removeBtn = row.querySelector('.remove-field');

        const onEdit = () => saveProfileChanges();
        
        keyInput.onblur = onEdit;
        valInput.onblur = onEdit;
        
        removeBtn.onclick = () => {
            const currentKey = row.dataset.key;
            removeField(currentKey);
        };
    });
}

async function saveProfileChanges() {
    if (selectedProfileIndex === -1) return;
    
    const rows = profileFieldsContainer.querySelectorAll('.profile-field-row');
    const newData = {};
    
    rows.forEach(row => {
        const key = row.querySelector('.key-input').value.trim();
        const val = row.querySelector('.val-input').value.trim();
        if (key) {
            newData[key] = val;
        }
    });

    const { autofillProfiles = [] } = await chrome.storage.local.get(['autofillProfiles']);
    if (autofillProfiles[selectedProfileIndex]) {
        autofillProfiles[selectedProfileIndex].data = newData;
        await chrome.storage.local.set({ autofillProfiles });
    }
}

async function addNewField() {
    if (selectedProfileIndex === -1) return;
    
    const { autofillProfiles = [] } = await chrome.storage.local.get(['autofillProfiles']);
    const profile = autofillProfiles[selectedProfileIndex];
    
    // Add a generic new field
    const newKey = "New Field " + (Object.keys(profile.data).length + 1);
    profile.data[newKey] = "";
    
    await chrome.storage.local.set({ autofillProfiles });
    renderProfileFields();
    
    // Focus the new key input
    setTimeout(() => {
        const lastRow = profileFieldsContainer.lastElementChild;
        if (lastRow) {
            const keyInput = lastRow.querySelector('.key-input');
            keyInput.focus();
            keyInput.select();
        }
    }, 50);
}

async function removeField(keyToDelete) {
    if (selectedProfileIndex === -1) return;
    
    const { autofillProfiles = [] } = await chrome.storage.local.get(['autofillProfiles']);
    const profile = autofillProfiles[selectedProfileIndex];
    
    if (profile.data[keyToDelete] !== undefined) {
        delete profile.data[keyToDelete];
        await chrome.storage.local.set({ autofillProfiles });
        renderProfileFields();
    }
}

function updateButtonsState() {
    // Instant Fill Button
    const hasFile = docInput && docInput.files && docInput.files.length > 0;
    if (currentBalance < 2) {
        autofillBtn.disabled = true;
        autofillBtn.textContent = 'Insufficient Balance (2 ৳ req)';
    } else if (!hasFile) {
        autofillBtn.disabled = true;
        autofillBtn.textContent = 'Upload Document';
    } else {
        autofillBtn.disabled = false;
        autofillBtn.textContent = 'Engine Autofill (2 ৳)';
    }

    // Profile Fill Button
    if (currentBalance < 1) {
        profileAutofillBtn.disabled = true;
        profileAutofillBtn.textContent = 'Insufficient Balance (1 ৳ req)';
    } else if (selectedProfileIndex === -1) {
        profileAutofillBtn.disabled = true;
        profileAutofillBtn.textContent = 'Select a Profile';
    } else {
        profileAutofillBtn.disabled = false;
        profileAutofillBtn.textContent = 'Fill with Profile (1 ৳)';
    }
}

// ==== Drag and Drop & File Handling ====

function formatBytes(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

function showFileInfo(file) {
    docDropZone.style.display = 'none';
    docFileInfo.style.display = 'flex';
    docFileName.textContent = file.name;
    docFileSize.textContent = formatBytes(file.size);
    updateButtonsState();
}

function clearFile() {
    docInput.value = '';
    docFileInfo.style.display = 'none';
    docDropZone.style.display = 'flex';
    extractionStatus.textContent = '';
    updateButtonsState();
}

if (docInput) {
    docInput.addEventListener('change', () => {
        if (docInput.files && docInput.files[0]) showFileInfo(docInput.files[0]);
    });
}
if (docClearBtn) docClearBtn.addEventListener('click', clearFile);

if (docDropZone) {
    docDropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        docDropZone.style.borderColor = '#3b82f6';
        docDropZone.style.background = '#eff6ff';
    });
    docDropZone.addEventListener('dragleave', () => {
        docDropZone.style.borderColor = '#cbd5e1';
        docDropZone.style.background = '#f8fafc';
    });
    docDropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        docDropZone.style.borderColor = '#cbd5e1';
        docDropZone.style.background = '#f8fafc';
        const files = e.dataTransfer.files;
        if (files && files[0]) {
            const dt = new DataTransfer();
            dt.items.add(files[0]);
            docInput.files = dt.files;
            showFileInfo(files[0]);
        }
    });
}

function setStatus(msg, color = '#3b82f6') {
    extractionStatus.textContent = msg;
    extractionStatus.style.color = color;
}

// ==== File Utilities (Same as Options or could be refactored) ====

function readFileAsText(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = e => resolve(e.target.result);
        reader.onerror = reject;
        reader.readAsText(file);
    });
}

function readFileAsBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = e => resolve(e.target.result);
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

function compressImageToBase64(file, maxSizeMB = 1.5) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = function (event) {
            const img = new Image();
            img.onload = function () {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;
                const MAX_DIMENSION = 1600;
                if (width > MAX_DIMENSION || height > MAX_DIMENSION) {
                    if (width > height) {
                        height = Math.round((height * MAX_DIMENSION) / width);
                        width = MAX_DIMENSION;
                    } else {
                        width = Math.round((width * MAX_DIMENSION) / height);
                        height = MAX_DIMENSION;
                    }
                }
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, width, height);
                const targetBytes = maxSizeMB * 1024 * 1024;
                let quality = 0.9;
                let base64 = canvas.toDataURL('image/jpeg', quality);
                while (base64.length * 0.75 > targetBytes && quality > 0.1) {
                    quality -= 0.1;
                    base64 = canvas.toDataURL('image/jpeg', quality);
                }
                resolve(base64);
            };
            img.onerror = reject;
            img.src = event.target.result;
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

async function extractDocxText(file) {
    const buffer = await file.arrayBuffer();
    const bytes = new Uint8Array(buffer);
    const decoder = new TextDecoder('utf-8');
    const readUint32 = (offset) => bytes[offset] | (bytes[offset + 1] << 8) | (bytes[offset + 2] << 16) | (bytes[offset + 3] << 24);
    const readUint16 = (offset) => bytes[offset] | (bytes[offset + 1] << 8);
    let offset = 0;
    while (offset < bytes.length - 30) {
        if (bytes[offset] !== 0x50 || bytes[offset + 1] !== 0x4B || bytes[offset + 2] !== 0x03 || bytes[offset + 3] !== 0x04) { offset++; continue; }
        const compression = readUint16(offset + 8);
        const compressedSz = readUint32(offset + 18);
        const filenameLen = readUint16(offset + 26);
        const extraLen = readUint16(offset + 28);
        const filename = decoder.decode(bytes.slice(offset + 30, offset + 30 + filenameLen));
        const dataStart = offset + 30 + filenameLen + extraLen;
        const compressedData = bytes.slice(dataStart, dataStart + compressedSz);
        if (filename === 'word/document.xml') {
            let xmlText;
            if (compression === 0) xmlText = decoder.decode(compressedData);
            else if (compression === 8) {
                const ds = new DecompressionStream('deflate-raw');
                const writer = ds.writable.getWriter();
                const reader = ds.readable.getReader();
                writer.write(compressedData);
                writer.close();
                const chunks = [];
                while (true) {
                    const { done, value } = await reader.read();
                    if (done) break;
                    chunks.push(value);
                }
                const total = chunks.reduce((n, c) => n + c.length, 0);
                const out = new Uint8Array(total);
                let pos = 0;
                for (const chunk of chunks) { out.set(chunk, pos); pos += chunk.length; }
                xmlText = decoder.decode(out);
            } else throw new Error(`Unsupported DOCX compression method: ${compression}`);
            return xmlText.replace(/<w:p[ />][^>]*>/g, '\n').replace(/<w:br[^>]*\/>/g, '\n').replace(/<w:tab[^>]*\/>/g, '\t').replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&#x[0-9A-Fa-f]+;/g, ' ').replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
        }
        offset = dataStart + compressedSz;
    }
    throw new Error('Not a valid document.xml in docx');
}

// ==== Execution ====

async function getPageContext() {
    return new Promise((resolve) => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0]) resolve({ url: tabs[0].url, title: tabs[0].title, tabId: tabs[0].id });
            else resolve(null);
        });
    });
}

// INSTANT AUTOFILL (Cost: 2 ৳)
autofillBtn.addEventListener('click', async () => {
    const file = docInput.files[0];
    if (!file) return;

    try {
        autofillBtn.disabled = true;
        setStatus('⏳ Processing document...');
        
        let payload = null;
        const isImage = file.type.startsWith('image/');
        const isPdf = file.type === 'application/pdf';
        const isText = file.type === 'text/plain' || file.name.endsWith('.txt');
        const isDocx = file.name.endsWith('.docx') || file.name.endsWith('.doc');

        if (isImage) {
            const base64 = await compressImageToBase64(file, 1.5);
            payload = { type: 'image', mimeType: file.type || 'image/jpeg', data: base64.split(',')[1] };
        } else if (isPdf) {
            const base64 = await readFileAsBase64(file);
            payload = { type: 'pdf', mimeType: 'application/pdf', data: base64.split(',')[1] };
        } else if (isText) {
            const text = await readFileAsText(file);
            payload = { type: 'text', mimeType: 'text/plain', data: text.slice(0, 15000) };
        } else if (isDocx) {
            const text = await extractDocxText(file);
            payload = { type: 'text', mimeType: 'text/plain', data: text.slice(0, 15000) };
        } else {
            throw new Error('Unsupported file type');
        }

        const context = await getPageContext();
        if (!context) throw new Error('Could not find active page context.');

        setStatus('⏳ Scraping form fields...');
        chrome.tabs.sendMessage(context.tabId, { action: "EXTRACT_PAGE_FIELDS" }, (response) => {
            if (chrome.runtime.lastError || !response?.success) {
                setStatus('Could not find forms. Refresh page and try again.', '#ef4444');
                autofillBtn.disabled = false;
                return;
            }

            setStatus('✨ Engine is analyzing & mapping...');
            
            chrome.storage.local.get(['selectedAiModel'], (res) => {
                const aiModel = res.selectedAiModel || 'fastest';
                
                chrome.runtime.sendMessage({
                    action: "PERFORM_CUSTOM_AUTOFILL",
                    document: payload,
                    targetFields: response.fields,
                    context: { url: context.url, title: context.title },
                    aiModel: aiModel
                }, (backgroundResponse) => {
                    if (backgroundResponse && backgroundResponse.success) {
                        setStatus('✅ Filling form...', '#10b981');
                        chrome.tabs.sendMessage(context.tabId, { action: "FILL_FORM", data: backgroundResponse.data }, () => {
                            setStatus('✅ Form filled successfully!', '#10b981');
                            fetchLimits(currentSession.access_token);
                        });
                    } else {
                        setStatus(backgroundResponse?.error || 'AI Extraction failed.', '#ef4444');
                        autofillBtn.disabled = false;
                    }
                });
            });
        });

    } catch (err) {
        setStatus('Error: ' + err.message, '#ef4444');
        autofillBtn.disabled = false;
    }
});

// PROFILE AUTOFILL (Cost: 1 ৳)
profileAutofillBtn.addEventListener('click', async () => {
    if (selectedProfileIndex === -1) return;

    try {
        profileAutofillBtn.disabled = true;
        const { autofillProfiles = [] } = await chrome.storage.local.get(['autofillProfiles']);
        const profile = autofillProfiles[selectedProfileIndex];
        
        const context = await getPageContext();
        if (!context) throw new Error('Could not find active page context.');

        setStatus('⏳ Scraping form fields...');
        chrome.tabs.sendMessage(context.tabId, { action: "EXTRACT_PAGE_FIELDS" }, (response) => {
            if (chrome.runtime.lastError || !response?.success) {
                setStatus('Could not find forms. Refresh page and try again.', '#ef4444');
                profileAutofillBtn.disabled = false;
                return;
            }

            setStatus('✨ AI is mapping profile data...');
            
            chrome.storage.local.get(['selectedAiModel'], (res) => {
                const aiModel = res.selectedAiModel || 'fastest';
                
                chrome.runtime.sendMessage({
                    action: "PERFORM_PROFILE_AUTOFILL",
                    profileData: profile.data,
                    targetFields: response.fields,
                    context: { url: context.url, title: context.title },
                    aiModel: aiModel
                }, (backgroundResponse) => {
                    if (backgroundResponse && backgroundResponse.success) {
                        setStatus('✅ Filling form...', '#10b981');
                        chrome.tabs.sendMessage(context.tabId, { action: "FILL_FORM", data: backgroundResponse.data }, () => {
                            setStatus('✅ Form filled successfully!', '#10b981');
                            fetchLimits(currentSession.access_token);
                        });
                    } else {
                        setStatus(backgroundResponse?.error || 'AI Mapping failed.', '#ef4444');
                        profileAutofillBtn.disabled = false;
                    }
                });
            });
        });
    } catch (err) {
        setStatus('Error: ' + err.message, '#ef4444');
        profileAutofillBtn.disabled = false;
    }
});

optionsBtn.addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
});

sidebarBtn.addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (chrome.sidePanel && tabs[0]) {
            chrome.sidePanel.open({ tabId: tabs[0].id });
        } else {
            chrome.runtime.openOptionsPage();
        }
    });
    window.close();
});

loginSettingsBtn.addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
});
