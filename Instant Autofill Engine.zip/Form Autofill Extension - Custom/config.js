const CONFIG = Object.freeze({
    // SERVER_URL: 'https://nexitsolution.bd',
    SERVER_URL: 'https://nexitsolution.bd',
    SUPABASE_URL: 'https://yowcwwmswbxutklckwgt.supabase.co',
    SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inlvd2N3d21zd2J4dXRrbGNrd2d0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzAwMjMwMDEsImV4cCI6MjA4NTU5OTAwMX0.NLRig5wdJb-NnUEZuHwqsaSEwo7tJt5hKsNsny33S8Y',
    GEMINI_MODEL: 'gemini-3-flash-preview',
});
