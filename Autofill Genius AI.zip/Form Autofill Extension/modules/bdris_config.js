export const BDRIS_FIELDS = {
    "personFirstNameBn": {
        "name": "personInfoForBirth.personFirstNameBn",
        "label": "First Name (Bengali)"
    },
    "personLastNameBn": {
        "name": "personInfoForBirth.personLastNameBn",
        "label": "Last Name (Bengali)"
    },
    "personFirstNameEn": {
        "name": "personInfoForBirth.personFirstNameEn",
        "label": "First Name (English)"
    },
    "personLastNameEn": {
        "name": "personInfoForBirth.personLastNameEn",
        "label": "Last Name (English)"
    },
    "personBirthDate": {
        "name": "personInfoForBirth.personBirthDate",
        "label": "Date of Birth (DD/MM/YYYY)"
    },
    "thChild": {
        "name": "personInfoForBirth.thChild",
        "label": "Child Order (N-th Child)"
    },
    "gender": {
        "name": "personInfoForBirth.gender",
        "label": "Gender (Bangla) [পুরুষ, মহিলা]"
    },
    "personNid": {
        "name": "personInfoForBirth.personNid",
        "label": "National ID (NID)"
    },
    "birthPlaceCountry": {
        "name": "birthPlaceCountry",
        "label": "Birth Place Country (Bangla)"
    },
    "birthPlaceDiv": {
        "name": "birthPlaceDiv",
        "label": "Birth Place Division"
    },
    "birthPlaceDist": {
        "name": "birthPlaceDist",
        "label": "Birth Place District"
    },
    "birthPlaceCityCorpCantOrUpazila": {
        "name": "birthPlaceCityCorpCantOrUpazila",
        "label": "Birth City Corporation / Upazila"
    },
    "birthPlacePaurasavaOrUnion": {
        "name": "birthPlacePaurasavaOrUnion",
        "label": "Birth Paurasava / Union"
    },
    "birthPlaceWardInPaurasavaOrUnion": {
        "name": "birthPlaceWardInPaurasavaOrUnion",
        "label": "Birth Ward / Village"
    },
    "birthPlacePostOfc": {
        "name": "birthPlacePostOfc",
        "label": "Birth Post Office (Bengali)"
    },
    "birthPlacePostOfcEn": {
        "name": "birthPlacePostOfcEn",
        "label": "Birth Post Office (English)"
    },
    "birthPlaceVilAreaTownBn": {
        "name": "birthPlaceVilAreaTownBn",
        "label": "Birth Village/Area/Town (Bengali)"
    },
    "birthPlaceVilAreaTownEn": {
        "name": "birthPlaceVilAreaTownEn",
        "label": "Birth Village/Area/Town (English)"
    },
    "birthPlaceHouseRoadBn": {
        "name": "birthPlaceHouseRoadBn",
        "label": "Birth House/Road (Bengali)"
    },
    "birthPlaceHouseRoadEn": {
        "name": "birthPlaceHouseRoadEn",
        "label": "Birth House/Road (English)"
    },
    "fatherBrn": {
        "name": "fatherBrn",
        "label": "Father's Birth Registration Number"
    },
    "fatherBirthDate": {
        "name": "fatherBirthDate",
        "label": "Father's Date of Birth"
    },
    "fatherNameBn": {
        "name": "fatherNameBn",
        "label": "Father's Name (Bengali)"
    },
    "fatherNameEn": {
        "name": "fatherNameEn",
        "label": "Father's Name (English)"
    },
    "fatherNationality": {
        "name": "fatherNationality",
        "label": "Father's Nationality"
    },
    "motherBrn": {
        "name": "motherBrn",
        "label": "Mother's Birth Registration Number"
    },
    "motherBirthDate": {
        "name": "motherBirthDate",
        "label": "Mother's Date of Birth"
    },
    "motherNameBn": {
        "name": "motherNameBn",
        "label": "Mother's Name (Bengali)"
    },
    "motherNameEn": {
        "name": "motherNameEn",
        "label": "Mother's Name (English)"
    },
    "motherNationality": {
        "name": "motherNationality",
        "label": "Mother's Nationality"
    },
    "permAddrCountry": {
        "name": "permAddrCountry",
        "label": "Perm. Address Country"
    },
    "permAddrDiv": {
        "name": "permAddrDiv",
        "label": "Perm. Address Division"
    },
    "permAddrDist": {
        "name": "permAddrDist",
        "label": "Perm. Address District"
    },
    "permAddrCityCorpCantOrUpazila": {
        "name": "permAddrCityCorpCantOrUpazila",
        "label": "Perm. City Corp/Upazila"
    },
    "permAddrPaurasavaOrUnion": {
        "name": "permAddrPaurasavaOrUnion",
        "label": "Perm. Paurasava/Union"
    },
    "permAddrWardInCityCorp": {
        "name": "permAddrWardInCityCorp",
        "label": "Perm. Ward (City Corp)"
    },
    "permAddrArea": {
        "name": "permAddrArea",
        "label": "Perm. Area/Zone"
    },
    "permAddrWardInPaurasavaOrUnion": {
        "name": "permAddrWardInPaurasavaOrUnion",
        "label": "Perm. Ward/Village"
    },
    "permAddrPostOfc": {
        "name": "permAddrPostOfc",
        "label": "Perm. Post Office (BN)"
    },
    "permAddrPostOfcEn": {
        "name": "permAddrPostOfcEn",
        "label": "Perm. Post Office (EN)"
    },
    "permAddrVilAreaTownBn": {
        "name": "permAddrVilAreaTownBn",
        "label": "Perm. Village/Area (BN)"
    },
    "permAddrVilAreaTownEn": {
        "name": "permAddrVilAreaTownEn",
        "label": "Perm. Village/Area (EN)"
    },
    "permAddrHouseRoadBn": {
        "name": "permAddrHouseRoadBn",
        "label": "Perm. House/Road (BN)"
    },
    "permAddrHouseRoadEn": {
        "name": "permAddrHouseRoadEn",
        "label": "Perm. House/Road (EN)"
    },
    "prsntAddrCountry": {
        "name": "prsntAddrCountry",
        "label": "Pres. Address Country"
    },
    "prsntAddrDiv": {
        "name": "prsntAddrDiv",
        "label": "Pres. Address Division"
    },
    "prsntAddrDist": {
        "name": "prsntAddrDist",
        "label": "Pres. Address District"
    },
    "prsntAddrCityCorpCantOrUpazila": {
        "name": "prsntAddrCityCorpCantOrUpazila",
        "label": "Pres. City Corp/Upazila"
    },
    "prsntAddrPaurasavaOrUnion": {
        "name": "prsntAddrPaurasavaOrUnion",
        "label": "Pres. Paurasava/Union"
    },
    "prsntAddrWardInCityCorp": {
        "name": "prsntAddrWardInCityCorp",
        "label": "Pres. Ward (City Corp)"
    },
    "prsntAddrArea": {
        "name": "prsntAddrArea",
        "label": "Pres. Area/Zone"
    },
    "prsntAddrWardInPaurasavaOrUnion": {
        "name": "prsntAddrWardInPaurasavaOrUnion",
        "label": "Pres. Ward/Village"
    },
    "prsntAddrPostOfc": {
        "name": "prsntAddrPostOfc",
        "label": "Pres. Post Office (BN)"
    },
    "prsntAddrPostOfcEn": {
        "name": "prsntAddrPostOfcEn",
        "label": "Pres. Post Office (EN)"
    },
    "prsntAddrVilAreaTownBn": {
        "name": "prsntAddrVilAreaTownBn",
        "label": "Pres. Village/Area (BN)"
    },
    "prsntAddrVilAreaTownEn": {
        "name": "prsntAddrVilAreaTownEn",
        "label": "Pres. Village/Area (EN)"
    },
    "prsntAddrHouseRoadBn": {
        "name": "prsntAddrHouseRoadBn",
        "label": "Pres. House/Road (BN)"
    },
    "prsntAddrHouseRoadEn": {
        "name": "prsntAddrHouseRoadEn",
        "label": "Pres. House/Road (EN)"
    }
};

export const BDRIS_DUMMY_PROFILE = {
    "id": "p_bdris_dummy",
    "name": "BDRIS Default Profile",
    "site": "bdris",
    "data": {
        "personFirstNameBn": "",
        "personLastNameBn": "",
        "personFirstNameEn": "",
        "personLastNameEn": "",
        "personBirthDate": "",
        "thChild": "",
        "gender": "",
        "personNid": "",
        "birthPlaceCountry": "",
        "birthPlaceDiv": "",
        "birthPlaceDist": "",
        "birthPlaceCityCorpCantOrUpazila": "",
        "birthPlacePaurasavaOrUnion": "",
        "birthPlaceWardInPaurasavaOrUnion": "",
        "birthPlacePostOfc": "",
        "birthPlacePostOfcEn": "",
        "birthPlaceVilAreaTownBn": "",
        "birthPlaceVilAreaTownEn": "",
        "birthPlaceHouseRoadBn": "",
        "birthPlaceHouseRoadEn": "",
        "fatherBrn": "",
        "fatherBirthDate": "",
        "fatherNameBn": "",
        "fatherNameEn": "",
        "fatherNationality": "",
        "motherBrn": "",
        "motherBirthDate": "",
        "motherNameBn": "",
        "motherNameEn": "",
        "motherNationality": "",
        "permAddrCountry": "",
        "permAddrDiv": "",
        "permAddrDist": "",
        "permAddrCityCorpCantOrUpazila": "",
        "permAddrPaurasavaOrUnion": "",
        "permAddrWardInCityCorp": "",
        "permAddrArea": "",
        "permAddrWardInPaurasavaOrUnion": "",
        "permAddrPostOfc": "",
        "permAddrPostOfcEn": "",
        "permAddrVilAreaTownBn": "",
        "permAddrVilAreaTownEn": "",
        "permAddrHouseRoadBn": "",
        "permAddrHouseRoadEn": "",
        "prsntAddrCountry": "",
        "prsntAddrDiv": "",
        "prsntAddrDist": "",
        "prsntAddrCityCorpCantOrUpazila": "",
        "prsntAddrPaurasavaOrUnion": "",
        "prsntAddrWardInCityCorp": "",
        "prsntAddrArea": "",
        "prsntAddrWardInPaurasavaOrUnion": "",
        "prsntAddrPostOfc": "",
        "prsntAddrPostOfcEn": "",
        "prsntAddrVilAreaTownBn": "",
        "prsntAddrVilAreaTownEn": "",
        "prsntAddrHouseRoadBn": "",
        "prsntAddrHouseRoadEn": ""
    }
};